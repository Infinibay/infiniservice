# Infiniservice Windows Installation Script
# This script installs and configures the Infiniservice on Windows VMs

param(
    [string]$ServiceMode = "normal",
    [string]$VmId = $null,
    [string]$InstallPath = "C:\Program Files\Infiniservice"
)

Write-Host "🚀 Starting Infiniservice installation..." -ForegroundColor Green
Write-Host "📁 Installation path: $InstallPath" -ForegroundColor Cyan
Write-Host "🔧 Service mode: $ServiceMode" -ForegroundColor Cyan

# Check if running as administrator
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Error "❌ This script must be run as Administrator!"
    exit 1
}

# Create installation directory
if (!(Test-Path $InstallPath)) {
    New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
    Write-Host "✅ Created installation directory: $InstallPath" -ForegroundColor Green
}

# Copy executable
$SourceExe = Join-Path $PSScriptRoot "infiniservice.exe"
$DestExe = Join-Path $InstallPath "infiniservice.exe"

if (Test-Path $SourceExe) {
    Copy-Item $SourceExe $DestExe -Force
    Write-Host "✅ Copied infiniservice.exe to $DestExe" -ForegroundColor Green
} else {
    Write-Error "❌ Source executable not found: $SourceExe"
    exit 1
}

# Create configuration file
$ConfigPath = Join-Path $InstallPath "config.toml"
$ConfigContent = @"
collection_interval = 30
log_level = "info"
service_name = "infiniservice"

# Windows virtio-serial device path will be auto-detected
virtio_serial_path = ""
"@

Set-Content -Path $ConfigPath -Value $ConfigContent
Write-Host "✅ Created configuration file: $ConfigPath" -ForegroundColor Green

# Set environment variables
if ($VmId) {
    [Environment]::SetEnvironmentVariable("INFINIBAY_VM_ID", $VmId, "Machine")
    Write-Host "✅ Set VM ID environment variable: $VmId" -ForegroundColor Green
}

if ($ServiceMode -eq "ping-pong") {
    [Environment]::SetEnvironmentVariable("INFINISERVICE_MODE", "ping-pong", "Machine")
    Write-Host "✅ Set service mode to ping-pong" -ForegroundColor Green
}

# Create Windows service
$ServiceName = "Infiniservice"
$ServiceDisplayName = "Infinibay Service"
$ServiceDescription = "Infinibay VM monitoring and communication service"

# Remove existing service if it exists
$ExistingService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($ExistingService) {
    Write-Host "🔄 Removing existing service..." -ForegroundColor Yellow
    Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
    sc.exe delete $ServiceName | Out-Null
    Start-Sleep -Seconds 2
}

# Create new service
$ServiceArgs = if ($ServiceMode -eq "ping-pong") { "--ping-pong" } else { "" }
$ServiceCommand = "`"$DestExe`" $ServiceArgs"

Write-Host "🔧 Creating Windows service..." -ForegroundColor Cyan
$CreateResult = sc.exe create $ServiceName binPath= $ServiceCommand DisplayName= $ServiceDisplayName start= auto
if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Service created successfully" -ForegroundColor Green
} else {
    Write-Error "❌ Failed to create service: $CreateResult"
    exit 1
}

# Set service description
sc.exe description $ServiceName $ServiceDescription | Out-Null

# Configure service recovery options
sc.exe failure $ServiceName reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null

# Start the service
Write-Host "🚀 Starting Infiniservice..." -ForegroundColor Cyan
$StartResult = Start-Service -Name $ServiceName -PassThru
if ($StartResult.Status -eq "Running") {
    Write-Host "✅ Infiniservice started successfully!" -ForegroundColor Green
} else {
    Write-Warning "⚠️ Service created but failed to start. Check Windows Event Log for details."
}

# Create uninstall script
$UninstallScript = Join-Path $InstallPath "uninstall.ps1"
$UninstallContent = @"
# Infiniservice Uninstall Script
Write-Host "🛑 Uninstalling Infiniservice..." -ForegroundColor Yellow

# Stop and remove service
Stop-Service -Name "$ServiceName" -Force -ErrorAction SilentlyContinue
sc.exe delete "$ServiceName" | Out-Null

# Remove environment variables
[Environment]::SetEnvironmentVariable("INFINIBAY_VM_ID", `$null, "Machine")
[Environment]::SetEnvironmentVariable("INFINISERVICE_MODE", `$null, "Machine")

# Remove installation directory
Remove-Item -Path "$InstallPath" -Recurse -Force -ErrorAction SilentlyContinue

Write-Host "✅ Infiniservice uninstalled successfully!" -ForegroundColor Green
"@

Set-Content -Path $UninstallScript -Value $UninstallContent
Write-Host "✅ Created uninstall script: $UninstallScript" -ForegroundColor Green

# Display service status
Write-Host "`n📊 Service Status:" -ForegroundColor Cyan
Get-Service -Name $ServiceName | Format-Table -AutoSize

Write-Host "`n🎉 Infiniservice installation completed successfully!" -ForegroundColor Green
Write-Host "📝 Configuration file: $ConfigPath" -ForegroundColor Cyan
Write-Host "🗑️ To uninstall, run: $UninstallScript" -ForegroundColor Cyan

if ($ServiceMode -eq "ping-pong") {
    Write-Host "`n🏓 Service is running in PING-PONG test mode" -ForegroundColor Yellow
    Write-Host "   Check the backend logs to see ping-pong communication" -ForegroundColor Yellow
}
